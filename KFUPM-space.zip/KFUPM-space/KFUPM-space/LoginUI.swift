//
//  ViewController.swift
//  KFUPM-space
//
//  Created by Mohammad on 18/05/1440 AH.
//  Copyright © 1440 Mohammad. All rights reserved.
//

import UIKit

class LoginUI: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

